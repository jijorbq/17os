#include "syscall.h"

extern void cstart(){
	while (1)	c_block_stone(0,0, 13, 40,7);
}