#include "syscall.h"

extern void cstart(){
	while (1)	c_snakewind(0,40, 13, 40);
}