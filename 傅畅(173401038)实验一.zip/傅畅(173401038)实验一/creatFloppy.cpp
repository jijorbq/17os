#include <bits/stdc++.h>
#define che
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define PB push_back
#define MP make_pair
#define fi first
#define se second
using namespace std;
typedef long long LL;

int main(){
	freopen("vfdd144","wt",stdout);
	for (int i=0;i<19;++i) putchar(0);
	return 0;
}

